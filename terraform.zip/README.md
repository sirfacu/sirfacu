* * * version 4.5.53
* Includes:
* * SERVICE
* * * updating the configuration and including nlb target groups to iterate over all the values in the super variable
* * ECS-CLUSTER
* * * moved the ecr repository to networking module

* * * version 4.5.52
* Includes:
* * NETWORKING
* * * including the listeners rules resources to alb pub and prv for https to create it in domain module were updated te outputs and variables files
* * DOMAIN
* * * removing lb_listener for https outputs and variable subdomain_names included
* * * including ACM certificate and validation for it
* * BASE
* * * variables and outputs updated to pointing to the correct resources

* * * version 4.5.25
* Includes:
* * NETWORKING
* * * removing the listeners rules resources to alb pub and prv for https to create it in domain module were updated te outputs and variables files
* * DOMAIN
* * * includes acm certificate generation, lb_listener for https outputs and variable subdomain_names included
* * SERVICES
* * * updated the local variable that contains the lb listener values
* * BASE
* * * variables and outputs updated to pointing to the correct resources

* * * version 4.5.21
* Includes:
* * NETWORKING
* * * includes the listeners rules resources to alb pub and prv for https

* * * version 4.5.17
* Includes:
* * SERVICES
* * * Updatig master_prv_data definitions and local listeners ids
* * NETWORKING
* * * Creating alb listener for https with default actions and removing variables definitions to port and protocol because its a default value

* * * version 4.5.12
* Includes:
* * SERVICES
* * * Updatig master_prv_data definitions

* * * version 4.5.11
* Includes:
* * NETWORKING
* * * updating sg networking names


* * * version 4.5.10

* Includes:
* * NETWORKING
* * * include listener rule for 443 in the ALB module and its variables
* * * 
* * SERVICES 
* * * Renaming the cluster-name

* * * version 4.5.9

* Includes:
* * SERVICES 
* * * New module that Include the definitions to create services

* * * version 4.4.0

* Includes:
* * SERVICE
* * * created the definitions to use service connect
* * * 
* * ECS-CLUSTER
* * * included the cloudwatch global group



* * * version 4.3.2

* Includes:

* * NETWORKING
* * * Splitting security groups for alb public, private, and nlb
* * * update the security groups to point cidr to use VPC cidr_block for ingress
* * * update the outputs from the module and also in the global outputs files

* * ECS-CLUSTER
* * * SG-ECS: was update to bring access to ALB private and public and NLB 
* * * Launch Template: configuring ecs-sg

* * README.MD Creating readme for changes