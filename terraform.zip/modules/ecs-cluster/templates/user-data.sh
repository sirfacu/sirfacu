#!/bin/bash
sudo mkdir /tmp/ssm
cd /tmp/ssm
sudo yum install -y https://s3.amazonaws.com/ec2-downloads-windows/SSMAgent/latest/linux_amd64/amazon-ssm-agent.rpm
echo "ECS_CLUSTER=${cluster_name}" | sudo tee /etc/ecs/ecs.config
echo "ECS_IMAGE_PULL_BEHAVIOR=once" | sudo tee -a /etc/ecs/ecs.config
echo "ECS_IMAGE_CLEANUP_INTERVAL=10m" | sudo tee -a /etc/ecs/ecs.config
echo "ECS_IMAGE_MINIMUM_CLEANUP_AGE=30m" | sudo tee -a /etc/ecs/ecs.config
echo "ECS_NUM_IMAGES_DELETE_PER_CYCLE=10" | sudo tee -a /etc/ecs/ecs.config
sudo rm /var/lib/ecs/data/agent.db
sudo start ecs
echo "Done"